class TokenModel{
  final String token;
  final int uid;
  TokenModel({
    required this.token,
    required this.uid
});
}